
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { type Express } from "express";
import session from "express-session";
import pgSession from "connect-pg-simple";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { pool, db } from "./db";
import { User as SelectUser, UserRole, otpRateLimits } from "@shared/schema";
import twilio from "twilio";
import { eq } from "drizzle-orm";

export function sanitizeUser(user: SelectUser) {
  const { password, ...safeUser } = user;
  return safeUser;
}

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);
const PgStore = pgSession(session);

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000;
const MAX_SEND_PER_WINDOW = 3;
const MAX_VERIFY_PER_WINDOW = 5;

async function checkAndUpdateRateLimit(phone: string, type: 'send' | 'verify'): Promise<{ allowed: boolean; message?: string }> {
  const now = new Date();
  const [existing] = await db.select().from(otpRateLimits).where(eq(otpRateLimits.phone, phone));

  if (!existing) {
    await db.insert(otpRateLimits).values({
      phone,
      sendCount: type === 'send' ? 1 : 0,
      verifyCount: type === 'verify' ? 1 : 0,
      windowStart: now,
    });
    return { allowed: true };
  }

  const windowAge = now.getTime() - new Date(existing.windowStart).getTime();
  if (windowAge > RATE_LIMIT_WINDOW_MS) {
    await db.update(otpRateLimits).set({
      sendCount: type === 'send' ? 1 : 0,
      verifyCount: type === 'verify' ? 1 : 0,
      windowStart: now,
    }).where(eq(otpRateLimits.phone, phone));
    return { allowed: true };
  }

  if (type === 'send' && existing.sendCount >= MAX_SEND_PER_WINDOW) {
    return { allowed: false, message: "Too many OTP requests. Please try again after 10 minutes." };
  }
  if (type === 'verify' && existing.verifyCount >= MAX_VERIFY_PER_WINDOW) {
    return { allowed: false, message: "Too many verification attempts. Please try again after 10 minutes." };
  }

  await db.update(otpRateLimits).set({
    sendCount: type === 'send' ? existing.sendCount + 1 : existing.sendCount,
    verifyCount: type === 'verify' ? existing.verifyCount + 1 : existing.verifyCount,
  }).where(eq(otpRateLimits.phone, phone));

  return { allowed: true };
}

export function setupAuth(app: Express) {
  app.set("trust proxy", 1);

  const isProduction = process.env.NODE_ENV === "production";
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "default_secret_key_should_be_changed",
    resave: false,
    saveUninitialized: false,
    store: new PgStore({
      pool: pool,
      createTableIfMissing: true,
    }),
    cookie: {
      secure: isProduction,
      sameSite: "lax" as const,
      httpOnly: true,
      maxAge: 365 * 24 * 60 * 60 * 1000,
    }
  };

  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (err) {
        return done(err);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  const twilioSid = process.env.TWILIO_ACCOUNT_SID;
  const twilioApiKey = process.env.TWILIO_API_KEY;
  const twilioApiSecret = process.env.TWILIO_API_SECRET;
  const twilioVerifySid = process.env.TWILIO_VERIFY_SERVICE_SID;
  const twilioConfigured = !!(twilioSid && twilioApiKey && twilioApiSecret && twilioVerifySid);
  let twilioClient: twilio.Twilio | null = null;

  if (twilioConfigured) {
    twilioClient = twilio(twilioApiKey, twilioApiSecret, { accountSid: twilioSid });
    console.log("Twilio Verify configured for SMS OTP");
    console.log("Twilio Account SID starts with:", twilioSid?.substring(0, 6) + "...");
    console.log("Twilio API Key starts with:", twilioApiKey?.substring(0, 6) + "...");
    console.log("Twilio Verify Service SID starts with:", twilioVerifySid?.substring(0, 6) + "...");
  } else {
    console.log("Twilio not configured - missing:", 
      !twilioSid ? "TWILIO_ACCOUNT_SID" : "", 
      !twilioApiKey ? "TWILIO_API_KEY" : "", 
      !twilioApiSecret ? "TWILIO_API_SECRET" : "",
      !twilioVerifySid ? "TWILIO_VERIFY_SERVICE_SID" : "");
  }

  app.post("/api/auth/send-otp", async (req, res) => {
    try {
      if (!twilioClient || !twilioVerifySid) {
        return res.status(503).json({ message: "OTP service is not configured" });
      }

      const { phone } = req.body;
      if (!phone || !/^\+\d{10,15}$/.test(phone)) {
        return res.status(400).json({ message: "Please enter a valid phone number in E.164 format (e.g., +919876543210)" });
      }

      const rateCheck = await checkAndUpdateRateLimit(phone, 'send');
      if (!rateCheck.allowed) {
        return res.status(429).json({ message: rateCheck.message });
      }

      await twilioClient.verify.v2
        .services(twilioVerifySid)
        .verifications.create({
          channel: "sms",
          to: phone,
        });

      res.json({ ok: true, message: "OTP sent via SMS", channel: "sms" });
    } catch (err: any) {
      console.error("Send OTP Twilio error:", {
        code: err?.code,
        message: err?.message,
        status: err?.status,
        moreInfo: err?.moreInfo,
      });
      if (err?.code === 60203) {
        return res.status(429).json({ message: "Max send attempts reached. Please try again later." });
      }
      if (err?.code === 60200) {
        return res.status(400).json({ message: "Invalid phone number. Please check and try again." });
      }
      res.status(500).json({ message: "Failed to send OTP. Please try again." });
    }
  });

  app.post("/api/auth/verify-otp", async (req, res) => {
    try {
      if (!twilioClient || !twilioVerifySid) {
        return res.status(503).json({ message: "OTP service is not configured" });
      }

      const { phone, code } = req.body;
      if (!phone || !/^\+\d{10,15}$/.test(phone)) {
        return res.status(400).json({ message: "Invalid phone number" });
      }
      if (!code || !/^\d{6}$/.test(code)) {
        return res.status(400).json({ message: "Invalid OTP code" });
      }

      const rateCheck = await checkAndUpdateRateLimit(phone, 'verify');
      if (!rateCheck.allowed) {
        return res.status(429).json({ message: rateCheck.message });
      }

      const verification = await twilioClient.verify.v2
        .services(twilioVerifySid)
        .verificationChecks.create({
          to: phone,
          code: code,
        });

      if (verification.status !== "approved") {
        return res.status(401).json({ message: "Invalid or expired OTP. Please try again." });
      }

      let user = await storage.getUserByPhone(phone);

      if (!user) {
        const randomSuffix = randomBytes(4).toString("hex");
        const username = `phone_${phone.replace('+', '')}_${randomSuffix}`;
        const placeholderPassword = await hashPassword(randomBytes(32).toString("hex"));

        user = await storage.createUser({
          username,
          password: placeholderPassword,
          name: `Customer`,
          email: null,
          phone: phone,
          role: UserRole.CUSTOMER,
          isActive: true,
        });
      }

      req.login(user, (loginErr) => {
        if (loginErr) {
          console.error("OTP login session error:", loginErr);
          return res.status(500).json({ message: "Login failed. Please try again." });
        }
        req.session.save((saveErr) => {
          if (saveErr) {
            console.error("OTP session save error:", saveErr);
            return res.status(500).json({ message: "Session error. Please try again." });
          }
          console.log("OTP login successful for user:", user!.id, phone);
          res.json({ ok: true, user: sanitizeUser(user!) });
        });
      });
    } catch (err: any) {
      console.error("Verify OTP Twilio error:", {
        code: err?.code,
        message: err?.message,
        status: err?.status,
        moreInfo: err?.moreInfo,
      });
      if (err?.code === 60202) {
        return res.status(429).json({ message: "Max check attempts reached. Please request a new OTP." });
      }
      res.status(500).json({ message: "Verification failed. Please try again." });
    }
  });

  app.get("/api/auth/otp/enabled", (_req, res) => {
    res.json({ enabled: twilioConfigured });
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).send("Username already exists");
      }

      const hashedPassword = await hashPassword(req.body.password);
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
      });

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(sanitizeUser(user));
      });
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(sanitizeUser(req.user!));
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(sanitizeUser(req.user!));
  });
}
